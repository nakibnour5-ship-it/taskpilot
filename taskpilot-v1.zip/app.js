/* TaskPilot AI — UI controller. No frameworks, no network, no innerHTML with user data. */
(function () {
  'use strict';

  var P = window.TaskPilotPlanner;
  var KEY = 'taskpilot.plan.v1';
  var state = { plan: null, done: {}, storageOK: true, lastFocus: null };

  var el = {
    form: document.getElementById('goal-form'),
    goal: document.getElementById('goal'),
    deadline: document.getElementById('deadline'),
    minutes: document.getElementById('minutes'),
    count: document.getElementById('goal-count'),
    error: document.getElementById('goal-error'),
    generate: document.getElementById('generate'),
    examples: document.getElementById('examples'),
    notice: document.getElementById('notice'),
    root: document.getElementById('plan-root'),
    skeleton: document.getElementById('plan-skeleton'),
    content: document.getElementById('plan-content'),
    toast: document.getElementById('toast'),
    sr: document.getElementById('sr-status')
  };

  /* ---------- small helpers ---------- */

  function h(tag, attrs) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'class') node.className = v;
        else if (k === 'text') node.textContent = v;
        else if (k === 'checked') node.checked = !!v;
        else if (k === 'disabled') node.disabled = !!v;
        else if (k === 'hidden') node.hidden = !!v;
        else node.setAttribute(k, v === true ? '' : String(v));
      });
    }
    for (var i = 2; i < arguments.length; i++) append(node, arguments[i]);
    return node;
  }

  function append(node, child) {
    if (child === null || child === undefined) return;
    if (Array.isArray(child)) { child.forEach(function (c) { append(node, c); }); return; }
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
  }

  function isoToday() {
    var d = new Date();
    return P.isoDate(d);
  }

  function prettyDate(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    if (!m) return iso;
    var d = new Date(+m[1], +m[2] - 1, +m[3], 12);
    try {
      return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
    } catch (e) { return iso; }
  }

  function toast(message, isError) {
    var t = el.toast;
    clearTimeout(toast._timer);
    t.textContent = message;
    t.hidden = false;
    t.classList.toggle('is-error', !!isError);
    requestAnimationFrame(function () { t.classList.add('is-visible'); });
    toast._timer = setTimeout(function () {
      t.classList.remove('is-visible');
      setTimeout(function () { t.hidden = true; }, 200);
    }, 2800);
  }

  function announce(message) { el.sr.textContent = message; }

  function showError(message, focusTarget) {
    el.error.textContent = message;
    el.error.hidden = false;
    el.goal.setAttribute('aria-invalid', 'true');
    if (focusTarget) focusTarget.focus();
  }

  function clearError() {
    el.error.hidden = true;
    el.error.textContent = '';
    el.goal.removeAttribute('aria-invalid');
  }

  /* ---------- storage ---------- */

  function storageAvailable() {
    try {
      var k = '__tp_test__';
      window.localStorage.setItem(k, '1');
      window.localStorage.removeItem(k);
      return true;
    } catch (e) { return false; }
  }

  function save() {
    if (!state.storageOK || !state.plan) return;
    try {
      window.localStorage.setItem(KEY, JSON.stringify({
        v: 1, savedAt: Date.now(), plan: state.plan, done: state.done
      }));
    } catch (e) {
      state.storageOK = false;
      showNotice('This browser is blocking local storage, so progress will reset when the tab closes. Use Copy or Download to keep the plan.');
    }
  }

  function load() {
    state.storageOK = storageAvailable();
    if (!state.storageOK) {
      showNotice('Local storage is unavailable (private mode or site data blocked). The planner still works, but progress will not persist — export the plan to keep it.');
      return;
    }
    var raw = null;
    try { raw = window.localStorage.getItem(KEY); } catch (e) { return; }
    if (!raw) return;
    var data;
    try { data = JSON.parse(raw); } catch (e) { discardSaved(); return; }
    if (!data || !data.plan || !Array.isArray(data.plan.tasks) || data.plan.version !== P.VERSION) {
      discardSaved();
      return;
    }
    state.plan = data.plan;
    state.done = (data.done && typeof data.done === 'object') ? data.done : {};
    el.goal.value = state.plan.goal;
    el.minutes.value = String(state.plan.minutesPerDay);
    if (state.plan.deadline) el.deadline.value = state.plan.deadline;
    updateCount();
    render();
    announce('Restored your saved plan.');
  }

  function discardSaved() {
    try { window.localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
  }

  function showNotice(message) {
    el.notice.textContent = message;
    el.notice.hidden = false;
  }

  /* ---------- generation ---------- */

  function generate() {
    clearError();
    var goal = el.goal.value.trim();
    var deadline = el.deadline.value;
    var minutes = el.minutes.value ? Number(el.minutes.value) : undefined;

    if (!goal) {
      showError('Describe your goal first — one sentence is enough.', el.goal);
      return;
    }

    el.generate.disabled = true;
    el.generate.querySelector('.btn-label').textContent = 'Building…';
    el.root.hidden = false;
    el.content.hidden = true;
    el.skeleton.hidden = false;
    el.skeleton.setAttribute('aria-hidden', 'false');
    announce('Building your plan.');

    // Defer so the loading state paints; the computation itself is synchronous and fast.
    setTimeout(function () {
      var result;
      try {
        result = P.createPlan({ goal: goal, deadline: deadline, minutesPerDay: minutes, now: new Date() });
      } catch (e) {
        result = { ok: false, error: 'Something went wrong while building the plan. Try a shorter goal.' };
      }

      el.generate.disabled = false;
      el.generate.querySelector('.btn-label').textContent = 'Build my plan';
      el.skeleton.hidden = true;
      el.skeleton.setAttribute('aria-hidden', 'true');

      if (!result.ok) {
        el.content.hidden = false;
        el.content.textContent = '';
        el.root.hidden = true;
        showError(result.error, el.goal);
        announce('Could not build the plan: ' + result.error);
        return;
      }

      state.plan = result.plan;
      state.done = {};
      save();
      render();
      el.content.hidden = false;
      announce('Plan ready: ' + result.plan.stats.taskCount + ' tasks across ' + result.plan.stats.phaseCount + ' phases. Saved on this device.');
      toast('Plan ready — saved on this device');
      var heading = document.getElementById('plan-title');
      if (heading) heading.focus({ preventScroll: true });
      var card = document.querySelector('.plan-card');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 0);
  }

  /* ---------- rendering ---------- */

  function render() {
    var plan = state.plan;
    if (!plan) { el.root.hidden = true; return; }
    el.root.hidden = false;
    el.content.textContent = '';

    var article = h('article', { class: 'plan-card', 'aria-labelledby': 'plan-title' });

    var head = h('header', { class: 'plan-head' },
      h('h2', { id: 'plan-title', tabindex: '-1', text: plan.title }),
      h('div', { class: 'plan-meta' },
        h('span', { class: 'pill pill-accent', text: plan.domainLabel }),
        h('span', { class: 'pill', text: plan.stats.taskCount + ' tasks' }),
        h('span', { class: 'pill', text: plan.stats.totalHours + 'h estimated' }),
        h('span', { class: 'pill', text: plan.stats.p1Count + ' high priority' }),
        h('span', { class: 'pill', text: 'due ' + plan.deadlineLabel })
      ),
      h('p', { class: 'plan-summary', text: plan.summary })
    );
    article.appendChild(head);

    var completeBanner = h('p', { class: 'plan-complete', hidden: true, text: 'Every task is checked off. Export the plan as a record, or build the next one.' });
    article.appendChild(completeBanner);

    var progressBlock = h('div', { class: 'progress-block' });
    var label = h('span', { class: 'progress-label' });
    var pctLabel = h('span', { class: 'progress-pct' });
    var track = h('div', {
      class: 'progress-track', role: 'progressbar',
      'aria-valuemin': '0', 'aria-valuemax': String(plan.tasks.length),
      'aria-valuenow': '0', 'aria-labelledby': 'plan-title'
    });
    var fill = h('div', { class: 'progress-fill' });
    track.appendChild(fill);
    progressBlock.appendChild(h('div', { class: 'progress-top' }, label, pctLabel));
    progressBlock.appendChild(track);
    article.appendChild(progressBlock);

    var actions = h('div', { class: 'actions' },
      h('button', { type: 'button', class: 'btn btn-sm', id: 'copy-plan', text: 'Copy Markdown' }),
      h('button', { type: 'button', class: 'btn btn-sm', id: 'download-md', text: 'Download .md' }),
      h('button', { type: 'button', class: 'btn btn-sm', id: 'download-ics', text: 'Add to calendar (.ics)' }),
      h('button', { type: 'button', class: 'btn btn-sm btn-ghost', id: 'new-plan', text: 'Start over' })
    );
    article.appendChild(actions);

    plan.tasks.forEach(function (task) { /* phases rendered below */ });
    var phaseNames = [];
    plan.tasks.forEach(function (t) {
      if (phaseNames.indexOf(t.phase) === -1) phaseNames.push(t.phase);
    });
    phaseNames.forEach(function (name) {
      var inPhase = plan.tasks.filter(function (t) { return t.phase === name; });
      var section = h('section', { class: 'phase', 'aria-label': 'Phase: ' + name });
      section.appendChild(h('h3', { class: 'phase-title' },
        name,
        h('span', { class: 'phase-count', text: inPhase.length + '' })
      ));
      var list = h('ul', { class: 'task-list' });
      inPhase.forEach(function (task) {
        list.appendChild(renderTask(task));
      });
      section.appendChild(list);
      article.appendChild(section);
    });

    if (plan.drafts && plan.drafts.length) {
      var drafts = h('section', { class: 'drafts', 'aria-label': 'Draft outputs' },
        h('h3', { text: 'Draft outputs' }),
        h('p', { class: 'hint', text: 'Templates, not generated prose. Edit before use.' })
      );
      plan.drafts.forEach(function (draft, i) {
        drafts.appendChild(renderDraft(draft, i));
      });
      article.appendChild(drafts);
    }

    var assumptions = h('section', { class: 'assumptions', 'aria-label': 'Assumptions' });
    var det = h('details', {},
      h('summary', { text: 'How this plan was made' }),
      h('ul', {}, plan.assumptions.map(function (a) { return h('li', { text: a }); }))
    );
    assumptions.appendChild(det);
    article.appendChild(assumptions);

    el.content.appendChild(article);

    // wiring after the DOM exists
    article.querySelectorAll('input[type="checkbox"]').forEach(function (box) {
      box.addEventListener('change', function () { toggleTask(box.dataset.taskId, box.checked); });
    });
    document.getElementById('copy-plan').addEventListener('click', copyPlan);
    document.getElementById('download-md').addEventListener('click', downloadMarkdown);
    document.getElementById('download-ics').addEventListener('click', downloadICS);
    document.getElementById('new-plan').addEventListener('click', resetPlan);
    updateProgress(label, pctLabel, track, fill, completeBanner);
  }

  function renderTask(task) {
    var id = 'task-' + task.id;
    var done = !!state.done[task.id];
    var meta = h('span', { class: 'task-meta' },
      h('span', { class: 'badge badge-' + task.priority.toLowerCase(), text: task.priority }),
      h('span', { text: ' ' + task.minutes + ' min · due ' + prettyDate(task.dueDate) + ' ' })
    );
    var label = h('label', { for: id, class: 'task-main' },
      h('span', { class: 'task-title', text: task.title }),
      meta
    );
    var row = h('div', { class: 'task-row' },
      h('input', {
        type: 'checkbox', id: id, 'data-task-id': task.id, checked: done,
        'aria-describedby': 'detail-' + task.id
      }),
      label
    );
    var detail = h('details', {},
      h('summary', { text: 'Why this matters' }),
      h('p', { class: 'task-detail', id: 'detail-' + task.id, text: task.detail })
    );
    return h('li', { class: 'task' + (done ? ' is-done' : ''), 'data-task-id': task.id }, row, detail);
  }

  function renderDraft(draft, index) {
    var pre = h('pre', { text: draft.body });
    var copy = h('button', {
      type: 'button', class: 'btn btn-sm btn-ghost', 'data-draft': String(index), text: 'Copy draft'
    });
    copy.addEventListener('click', function () {
      copyText(draft.body).then(function (ok) {
        toast(ok ? 'Draft copied' : 'Could not copy — long-press the text instead', !ok);
      });
    });
    return h('details', { class: 'draft' },
      h('summary', { text: draft.title }),
      pre,
      h('div', { class: 'draft-actions' }, copy)
    );
  }

  function toggleTask(id, checked) {
    if (!state.plan) return;
    if (checked) state.done[id] = true; else delete state.done[id];
    var li = document.querySelector('.task[data-task-id="' + id + '"]');
    if (li) li.classList.toggle('is-done', checked);
    var label = document.querySelector('.progress-label');
    var pct = document.querySelector('.progress-pct');
    var track = document.querySelector('.progress-track');
    var fill = document.querySelector('.progress-fill');
    var banner = document.querySelector('.plan-complete');
    if (track && fill) updateProgress(label, pct, track, fill, banner);
    save();
    var doneCount = Object.keys(state.done).length;
    if (doneCount === state.plan.tasks.length) {
      announce('All tasks complete.');
      toast('All tasks complete — nice work');
    }
  }

  function updateProgress(label, pctLabel, track, fill, banner) {
    if (!state.plan) return;
    var total = state.plan.tasks.length;
    var done = state.plan.tasks.filter(function (t) { return state.done[t.id]; }).length;
    var pct = total ? Math.round((done / total) * 100) : 0;
    if (label) label.textContent = done + ' of ' + total + ' done';
    if (pctLabel) pctLabel.textContent = pct + '%';
    if (track) track.setAttribute('aria-valuenow', String(done));
    if (fill) {
      fill.style.width = pct + '%';
      fill.classList.toggle('is-complete', pct === 100 && total > 0);
    }
    if (banner) banner.hidden = !(pct === 100 && total > 0);
  }

  /* ---------- exports ---------- */

  function copyText(text) {
    return new Promise(function (resolve) {
      var fallback = function () {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.top = '-1000px';
        document.body.appendChild(ta);
        ta.select();
        var ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
        document.body.removeChild(ta);
        resolve(ok);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function () { resolve(true); }, fallback);
      } else {
        fallback();
      }
    });
  }

  function copyPlan() {
    if (!state.plan) return;
    copyText(P.toMarkdown(state.plan, state.done)).then(function (ok) {
      toast(ok ? 'Plan copied as Markdown' : 'Copy blocked — use Download instead', !ok);
    });
  }

  function download(name, text, mime) {
    try {
      var blob = new Blob([text], { type: mime });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
      return true;
    } catch (e) {
      return false;
    }
  }

  function slug() {
    return (state.plan ? state.plan.title : 'plan')
      .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'plan';
  }

  function downloadMarkdown() {
    if (!state.plan) return;
    var ok = download('taskpilot-' + slug() + '.md', P.toMarkdown(state.plan, state.done), 'text/markdown;charset=utf-8');
    toast(ok ? 'Download started — if nothing happens, use Copy Markdown' : 'Download failed — use Copy Markdown', !ok);
  }

  function downloadICS() {
    if (!state.plan) return;
    var ok = download('taskpilot-' + slug() + '.ics', P.toICS(state.plan, new Date()), 'text/calendar;charset=utf-8');
    toast(ok ? 'Calendar file ready — import it in your calendar app' : 'Calendar export failed', !ok);
  }

  function resetPlan() {
    var hasProgress = Object.keys(state.done).length > 0;
    if (hasProgress && !window.confirm('Start over? This clears your current plan and checked tasks on this device.')) return;
    state.plan = null;
    state.done = {};
    try { window.localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    el.root.hidden = true;
    el.content.textContent = '';
    el.goal.value = '';
    el.deadline.value = '';
    el.minutes.value = '60';
    updateCount();
    clearError();
    el.goal.focus();
    announce('Plan cleared.');
  }

  /* ---------- input wiring ---------- */

  function updateCount() {
    el.count.textContent = el.goal.value.length + '/' + P.MAX_GOAL;
  }

  function bind() {
    el.form.addEventListener('submit', function (e) { e.preventDefault(); generate(); });
    el.goal.addEventListener('input', function () { updateCount(); clearError(); });
    el.examples.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-goal]');
      if (!btn) return;
      el.goal.value = btn.dataset.goal;
      updateCount();
      clearError();
      el.goal.focus();
      el.goal.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    el.deadline.min = isoToday();
  }

  bind();
  load();
  updateCount();
})();
