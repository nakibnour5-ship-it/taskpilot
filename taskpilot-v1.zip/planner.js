/* TaskPilot AI — deterministic planning engine.
 * No network, no AI model calls. Pure functions: same input -> same output.
 * Browser: window.TaskPilotPlanner. Node: module.exports (for tests).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TaskPilotPlanner = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.0.0';
  var MIN_GOAL = 12;
  var MAX_GOAL = 600;
  var DAY_MS = 86400000;

  var DOMAINS = {
    exam: {
      label: 'Exam / revision',
      horizon: 14,
      keywords: ['exam', 'test', 'study', 'studying', 'revise', 'revision', 'final', 'finals', 'midterm', 'quiz', 'grade', 'school', 'university', 'college', 'bac', 'concours', 'semester'],
      summary: 'A revision sequence that starts with a diagnostic, concentrates on weak topics, and ends with timed practice — not a topic list.',
      phases: [
        { name: 'Diagnose', tasks: [
          ['List every topic and its exam weighting', 'Pull the syllabus or past paper. Mark each topic high / medium / low by marks available, not by how much you like it.', 25],
          ['Take one timed diagnostic paper', 'Closed book, real time limit. Score it and list every lost mark by topic. This decides what you study.', 60]
        ] },
        { name: 'Learn the weak topics', tasks: [
          ['Build a one-page summary per weak topic', 'One page maximum: definition, formula or framework, one worked example, two common traps.', 45],
          ['Do 10 practice questions per weak topic', 'Mix easy and exam-level. Mark immediately and write why each wrong answer was wrong.', 45],
          ['Explain each weak topic out loud in 2 minutes', 'If you cannot explain it without notes, it is not learned yet. Note where you stall.', 20, 'P2']
        ] },
        { name: 'Practice under pressure', tasks: [
          ['Complete a full past paper under exam conditions', 'Phone away, timer on, no notes. This is the rehearsal that matters.', 90],
          ['Mark it and log every lost mark', 'Group losses: knowledge gap, misread question, time pressure, careless error. Each group needs a different fix.', 30],
          ['Re-drill only the topics that lost marks', 'Targeted beats general. Do not re-read what you already get right.', 45],
          ['Second timed paper — aim for +10%', 'Compare against the first paper. Improvement is the signal, not the score.', 90, 'P2']
        ] },
        { name: 'Final review', tasks: [
          ['Write a 10-line cheat sheet from memory', 'Then check it against your notes. Fix only the gaps you find.', 20],
          ['Confirm exam time, room, and materials', 'ID, calculator, pens, water, transport. Remove tomorrow-morning surprises.', 10]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Revision log (one per session)',
          body: 'Topic:\n' + ctx.goal + '\n\nWhat I did (minutes):\nWhat I got wrong:\nWhy I got it wrong (knowledge / misread / time / careless):\nWhat I will do next session:\n' };
      }, function (ctx) {
        return { title: 'Message to a teacher or study partner',
          body: 'Hi — I am working toward: ' + ctx.goal + '.\nI have my diagnostic done and I am drilling my weakest topics first.\nCould you check my approach to [topic] and tell me if I am missing anything major?\nI am aiming to be ready by ' + ctx.deadlineLabel + '.' };
      }]
    },

    career: {
      label: 'Job / internship search',
      horizon: 21,
      keywords: ['job', 'apply', 'application', 'resume', 'cv', 'interview', 'internship', 'career', 'portfolio', 'hiring', 'recruiter', 'linkedin'],
      summary: 'A search cadence: target roles, tailor materials, submit in batches, and follow up — with interview prep scheduled before you need it.',
      phases: [
        { name: 'Target', tasks: [
          ['Shortlist 10 roles that match your actual skills', 'Save the links. Note salary range, location, and the one requirement you do not meet yet.', 45],
          ['Map each role to its top 3 requirements', 'A simple table: role, requirement, your evidence. This exposes where you are generic.', 30]
        ] },
        { name: 'Materials', tasks: [
          ['Rewrite your CV summary for the target role', 'Three lines: what you do, proof, what you want next. No adjectives without evidence.', 45],
          ['Add three measurable results to your CV', 'Numbers, scope, or outcome. "Improved X from A to B" beats "responsible for X".', 40],
          ['Draft a 150-word tailored cover letter', 'One paragraph on the role, one on your proof, one on the next step. Reuse the skeleton, never the text.', 45]
        ] },
        { name: 'Apply', tasks: [
          ['Submit three applications', 'Quality over volume, but three is the minimum that creates a feedback loop.', 45],
          ['Log every application in one tracker', 'Role, date, contact, status, next follow-up date. Memory is not a system.', 15, 'P2'],
          ['Prepare six STAR stories', 'Situation, Task, Action, Result. Cover conflict, failure, leadership, ambiguity, delivery, learning.', 60]
        ] },
        { name: 'Follow up and prepare', tasks: [
          ['Send one follow-up five working days later', 'Two sentences, restate interest, offer a concrete detail. No guilt, no essay.', 10, 'P2'],
          ['Run a 20-minute mock interview out loud', 'Record it. Watch for filler, missing results, and answers over two minutes.', 20],
          ['Review replies and change one thing', 'If no replies after 10 applications, the problem is targeting or the CV summary — not luck.', 25]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Cover letter skeleton',
          body: 'Dear [Hiring manager],\n\nI am applying for [role] at [company]. I build [specific thing] and the part of this role I am strongest at is [requirement 1].\n\nEvidence: [result with a number], [project or experience], [skill they asked for].\n\nWhat I want next: [one sentence about the work you want to do]. I am available from [date] and based in [location / remote].\n\nThank you for your time,\n[Name] — [portfolio link]\n\n-- Edit before sending. Placeholders in brackets are deliberate.' };
      }, function (ctx) {
        return { title: 'Application tracker header',
          body: 'Goal: ' + ctx.goal + '\n\n| Role | Company | Date | Contact | Status | Follow-up |\n|---|---|---|---|---|---|\n|  |  |  |  | applied |  |\n' };
      }]
    },

    fitness: {
      label: 'Fitness / training',
      horizon: 28,
      keywords: ['run', 'running', 'marathon', '5k', '10k', 'gym', 'workout', 'fitness', 'weight', 'lose', 'muscle', 'train', 'training', 'exercise', 'walk'],
      summary: 'A graded progression with rest built in: baseline, repeatable weekly sessions, one measurable retest, and an adjustment rule.',
      phases: [
        { name: 'Baseline', tasks: [
          ['Measure where you actually are', 'Walk or run 1 km at a comfortable pace and note the time. No hero efforts — this is a baseline.', 30],
          ['Choose three days that fit your real week', 'Put them in the calendar now. A plan that ignores your schedule is fiction.', 15],
          ['Clear the friction', 'Shoes by the door, route decided, playlist ready. Remove one excuse before you need willpower.', 15, 'P3']
        ] },
        { name: 'Build the habit', tasks: [
          ['Session 1: easy intervals, 20 minutes', 'Run 1 minute, walk 2. Repeat. If you cannot talk, slow down.', 25],
          ['Add one easy 30-minute walk', 'Recovery is training. Keep it genuinely easy.', 30, 'P2'],
          ['Session 2: same intervals, 30s more running', 'Small increase only. Consistency beats intensity this week.', 25]
        ] },
        { name: 'Progress', tasks: [
          ['Session 3: 20 minutes continuous', 'Slow enough to finish. Speed comes later.', 25],
          ['Retest the 1 km', 'Same route, same effort level. Compare with baseline, not with anyone else.', 20],
          ['Review and adjust next week', 'If a session was missed, repeat the week instead of skipping ahead.', 15, 'P2']
        ] },
        { name: 'Consolidate', tasks: [
          ['Plan next week from what actually worked', 'Keep the days that survived contact with real life. Drop the rest.', 15],
          ['Protect sleep for three nights', 'Seven hours minimum. Training adapts during recovery, not during the session.', 10, 'P2']
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Session log',
          body: 'Goal: ' + ctx.goal + '\n\nDate:\nSession:\nPlanned effort:\nActual:\nWhat felt hard:\nNext session adjustment:\n' };
      }]
    },

    writing: {
      label: 'Writing project',
      horizon: 14,
      keywords: ['write', 'writing', 'blog', 'article', 'book', 'essay', 'newsletter', 'thesis', 'novel', 'script', 'post', 'content'],
      summary: 'A draft-first sequence: promise, reader questions, outline, an intentionally bad first draft, then editing passes with a shipping deadline.',
      phases: [
        { name: 'Frame', tasks: [
          ['Write the one-sentence promise', 'Who is this for, what will they be able to do after reading, and why should they believe you?', 15],
          ['List five questions a reader would ask', 'Answer them in the piece. If you cannot answer one, that is your research task.', 20],
          ['Collect three sources or concrete examples', 'Specific beats abstract. Save links and the exact quote you might use.', 40]
        ] },
        { name: 'Draft', tasks: [
          ['Outline: hook, three sections, takeaway', 'One line per section. If a section has no point, cut it before writing it.', 30],
          ['Draft section one badly — no editing', 'Permission to write badly is the only way to start. Fix later.', 30],
          ['Draft the remaining sections', 'Keep momentum. Mark weak spots with [FIX] instead of stopping.', 60]
        ] },
        { name: 'Edit', tasks: [
          ['Cut 10% and rewrite the opening', 'The first line earns the second. Delete throat-clearing.', 30, 'P2'],
          ['Read it aloud and fix awkward lines', 'Your ear catches what your eye skips.', 20, 'P2'],
          ['Add title options and a summary line', 'Three titles, pick one. The summary is what people actually read.', 15, 'P3']
        ] },
        { name: 'Ship', tasks: [
          ['Publish in one place', 'Perfect is a reason to never ship. Publish where your readers already are.', 15],
          ['Share it with three specific people', 'Ask one question: where did you stop reading?', 15]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Article outline',
          body: '# [Working title]\n\nPromise: after reading this, the reader can [outcome].\n\n## Hook\n[Concrete scene, number, or contradiction]\n\n## 1. [Point]\nEvidence:\n\n## 2. [Point]\nEvidence:\n\n## 3. [Point]\nEvidence:\n\n## Takeaway\n[One action the reader can take today]\n\nGoal context: ' + ctx.goal };
      }]
    },

    launch: {
      label: 'Launch / small business',
      horizon: 21,
      keywords: ['launch', 'startup', 'business', 'product', 'sell', 'selling', 'revenue', 'customer', 'customers', 'mvp', 'freelance', 'clients', 'shop', 'store'],
      summary: 'Demand before build: talk to people who have the problem, define one paid outcome, publish a one-page offer, then deliver manually.',
      phases: [
        { name: 'Validate', tasks: [
          ['Write the problem in one sentence', 'Who has it, when does it hurt, and what do they do today instead?', 15],
          ['List ten people who actually have this problem', 'Names, not demographics. If you cannot name ten, your audience is too vague.', 20],
          ['Talk to three of them', 'Ask what they do now, what it costs them, and what they tried. Do not pitch.', 60]
        ] },
        { name: 'Define the offer', tasks: [
          ['Define the smallest paid outcome', 'A result someone would pay for this week — not a platform, not a brand.', 25],
          ['Write a one-page offer: who, what, price, proof', 'One page. If it needs a diagram, it is not clear enough.', 45],
          ['Set up one way to collect payment or interest', 'A payment link or a form. Nothing else until someone says yes.', 40]
        ] },
        { name: 'Distribute', tasks: [
          ['Share the page with twenty relevant people', 'Direct messages beat broadcasts. One sentence of context each.', 30],
          ['Track replies and objections', 'Every objection is either a pricing signal or a positioning signal.', 20, 'P2'],
          ['Deliver the first paid job manually', 'Do it by hand. Learn what to automate from the actual work.', 60]
        ] },
        { name: 'Decide', tasks: [
          ['Change one variable: offer, price, or audience', 'One at a time, or you learn nothing.', 30, 'P2'],
          ['Write down what you would need to see to continue', 'A number: replies, calls, or sales. Decide before emotion gets involved.', 15]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'One-page offer copy',
          body: 'Headline: [Outcome] for [specific person]\n\nProblem: [What they struggle with today]\n\nWhat you get:\n- [Deliverable 1]\n- [Deliverable 2]\n- [Turnaround]\n\nPrice: [amount] — [what is included]\n\nProof: [one real result, or "new — first three clients get a reduced rate"]\n\nNext step: [payment link or reply-to email]\n\nGoal context: ' + ctx.goal + '\n\n-- Every claim must be true. Replace placeholders with real evidence before sharing.' };
      }]
    },

    coding: {
      label: 'Software project',
      horizon: 14,
      keywords: ['code', 'coding', 'programming', 'python', 'javascript', 'build', 'api', 'algorithm', 'app', 'website', 'developer', 'software', 'bug'],
      summary: 'A vertical-slice sequence: smallest runnable version, one useful feature, tests on the riskiest logic, then a real user.',
      phases: [
        { name: 'Scope', tasks: [
          ['Define the smallest runnable version', 'One user, one job, one screen. Write what is explicitly out of scope.', 20],
          ['Set up the project and run hello world', 'Toolchain working before features. Commit the empty shell.', 30]
        ] },
        { name: 'Build', tasks: [
          ['Build the core data flow end to end', 'Input to output, even if ugly. A working spine beats polished limbs.', 60],
          ['Add the one feature that makes it useful', 'The thing a user would miss if it disappeared.', 60]
        ] },
        { name: 'Test', tasks: [
          ['Write three tests for the riskiest logic', 'Not for coverage — for the parts where a silent bug would hurt most.', 45],
          ['Fix what the tests expose', 'Resist changing the test to match the bug.', 45],
          ['Test on a phone-sized screen', '320px width, real thumb, slow connection if possible.', 25, 'P2']
        ] },
        { name: 'Ship', tasks: [
          ['Write a five-line README', 'What it does, how to run it, what is not done yet.', 15, 'P3'],
          ['Put it in front of one real user', 'Watch them use it without helping. That is the real test.', 20]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'README skeleton',
          body: '# [Project]\n\nOne line: what it does for whom.\n\n## Run\n```\n[command]\n```\n\n## Works\n-\n\n## Not done yet\n-\n\n## Known risks\n-\n\nGoal context: ' + ctx.goal };
      }]
    },

    travel: {
      label: 'Trip planning',
      horizon: 21,
      keywords: ['trip', 'travel', 'vacation', 'holiday', 'itinerary', 'visit', 'flight', 'tour', 'hotel', 'abroad', 'weekend away'],
      summary: 'A booking-first sequence with a day-by-day skeleton and an offline pack, so the trip survives bad signal and changed plans.',
      phases: [
        { name: 'Decide', tasks: [
          ['Fix dates and a budget ceiling', 'Total number, including transport and food. Everything else follows from this.', 20],
          ['Shortlist three areas to stay', 'Compare transport to the things you actually want to do, not to the photos.', 30]
        ] },
        { name: 'Book', tasks: [
          ['Book transport', 'Check cancellation terms before price. A cheap ticket you cannot change is a trap.', 30],
          ['Book a stay with free cancellation', 'Free cancellation until close to the date buys you flexibility.', 25],
          ['Check documents, visas, and insurance', 'Passport validity, entry rules, and what your insurance actually covers.', 25]
        ] },
        { name: 'Plan', tasks: [
          ['Build a day-by-day skeleton with two anchors', 'Two fixed points per day, empty space between them. Over-scheduling ruins trips.', 40],
          ['Make a packing list by category', 'Documents, clothes, tech, health. Reuse it next time.', 20, 'P2'],
          ['Download offline maps and confirmations', 'Screenshots of bookings plus offline maps. Assume no signal on arrival.', 15, 'P2']
        ] },
        { name: 'Before you go', tasks: [
          ['Share the itinerary with one person', 'Where you are, when, and a check-in rhythm.', 10],
          ['Confirm the first 24 hours', 'Airport transfer, check-in time, first meal. Arrival is when plans break.', 15]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Itinerary skeleton',
          body: 'Trip: ' + ctx.goal + '\nDates:\n\nDay 1 — arrive\nAnchor 1:\nAnchor 2:\nFood:\n\nDay 2\nAnchor 1:\nAnchor 2:\nFood:\n\nDay 3\nAnchor 1:\nAnchor 2:\nFood:\n\nBookings:\n- Transport:\n- Stay:\n- Insurance:\n\nEmergency contact:\n' };
      }]
    },

    event: {
      label: 'Event / gathering',
      horizon: 21,
      keywords: ['event', 'wedding', 'party', 'conference', 'meetup', 'workshop', 'birthday', 'organize', 'organise', 'reunion', 'ceremony'],
      summary: 'A logistics sequence: lock the constraints, invite early, script the day, and assign jobs to named people.',
      phases: [
        { name: 'Lock constraints', tasks: [
          ['Lock date, headcount, and budget', 'These three decide everything else. Write them down before browsing venues.', 20],
          ['Pick a venue and confirm availability', 'Ask about chairs, sound, access, and the cleanup rule.', 45]
        ] },
        { name: 'Invite', tasks: [
          ['Send invitations with an RSVP deadline', 'Deadline at least a week before you must confirm numbers.', 30],
          ['Confirm food and drinks for the final count', 'Include one vegetarian and one allergen-safe option by default.', 30]
        ] },
        { name: 'Plan the day', tasks: [
          ['Write a run-of-show, hour by hour', 'Setup, arrivals, main moment, food, wind-down, cleanup.', 40],
          ['Assign three jobs to three named people', 'Setup, door, cleanup. A job without a name is unassigned.', 20, 'P2'],
          ['Buy or borrow the supplies', 'One list, one trip. Check return dates for borrowed items.', 40, 'P2']
        ] },
        { name: 'Execute', tasks: [
          ['Send a reminder 48 hours before', 'Time, address, what to bring, who to call.', 10],
          ['Prepare the day-of checklist and a backup plan', 'Weather, late food, no-shows, dead phone battery.', 25]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Invitation and run-of-show',
          body: 'You are invited: [event]\nWhen: [date, start-end]\nWhere: [address + map link]\nBring: [one thing]\nRSVP by: [date] to [contact]\n\n---\nRun of show\n[time] setup\n[time] doors\n[time] main moment\n[time] food\n[time] cleanup\n\nContext: ' + ctx.goal };
      }]
    },

    home: {
      label: 'Home / decluttering',
      horizon: 10,
      keywords: ['clean', 'cleaning', 'declutter', 'move', 'moving', 'apartment', 'house', 'kitchen', 'room', 'tidying', 'organize', 'organise', 'laundry'],
      summary: 'One room at a time, a keep/donate/bin decision rule, a home for every kept item, and a short daily reset.',
      phases: [
        { name: 'Pick and prepare', tasks: [
          ['Pick one room and set a 20-minute timer', 'One room. Not the whole house. Stop when the timer ends.', 20],
          ['Clear one surface completely', 'A visible clear surface creates momentum better than a cleaning schedule.', 20]
        ] },
        { name: 'Sort', tasks: [
          ['Sort everything into keep / donate / bin', 'If you have not used it in a year, it is donate or bin. No maybe pile.', 45],
          ['Set a home for every kept item', 'A place it returns to. Otherwise it will be clutter again in a week.', 40],
          ['Take the donation bag out of the house', 'In the car or at the drop-off point. Bags in the hallway become furniture.', 20, 'P2']
        ] },
        { name: 'Maintain', tasks: [
          ['Do a 10-minute daily reset for three days', 'Timer on, everything back to its home. Short and repeatable beats deep and rare.', 10, 'P2'],
          ['Deep clean the neglected area', 'The one behind the door or under the sink. Set a timer, not a standard.', 45, 'P2'],
          ['Schedule the donation drop-off', 'A date in the calendar converts intent into a finished task.', 15, 'P3']
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Donation and reset checklist',
          body: 'Room: [room]\n\nDonate box:\n-\nBin bag:\n-\nKeep (needs a home):\n-\n\nDaily reset, 10 minutes:\n1. Clear the main surface\n2. Return five things to their home\n3. Take out the bin\n\nContext: ' + ctx.goal };
      }]
    },

    generic: {
      label: 'General goal',
      horizon: 14,
      keywords: [],
      summary: 'A general sequence that turns an outcome into a testable definition of done, a first action, and scheduled work blocks.',
      phases: [
        { name: 'Define', tasks: [
          ['Write the outcome as one testable sentence', 'Something you could hand to a friend and ask "is this done?"', 15],
          ['List three checks that prove it is finished', 'Observable evidence, not feelings.', 20]
        ] },
        { name: 'Start', tasks: [
          ['Identify the first 30-minute action', 'Small enough that you cannot talk yourself out of it today.', 15],
          ['Do that first action', 'Momentum first, plan refinement second.', 30],
          ['List the blockers and one way around each', 'For each blocker: what you control, what you need from someone else.', 25, 'P2']
        ] },
        { name: 'Work the blocks', tasks: [
          ['Book two work blocks this week', 'Specific times in the calendar, phone away.', 15],
          ['Complete work block one', 'One outcome per block. Stop when the outcome is reached.', 45, 'P2'],
          ['Complete work block two', 'Same rule. Log what you finished.', 45, 'P2']
        ] },
        { name: 'Review', tasks: [
          ['Review progress and cut one thing', 'A plan that only grows is a plan you will abandon.', 20],
          ['Decide the next single step', 'One step, written down, scheduled.', 15]
        ] }
      ],
      drafts: [function (ctx) {
        return { title: 'Weekly review note',
          body: 'Goal: ' + ctx.goal + '\n\nDone this week:\n-\n\nBlocked by:\n-\n\nNext single step:\n\nWhen I will do it:\n' };
      }]
    }
  };

  /* ---------- date helpers ---------- */

  function startOfDay(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12, 0, 0, 0); }
  function addDays(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n, 12, 0, 0, 0); }
  function isoDate(d) {
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (day < 10 ? '0' + day : day);
  }
  function parseISODate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || '').trim());
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    var dt = new Date(y, mo - 1, d, 12, 0, 0, 0);
    if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
    return dt;
  }
  function daysBetween(a, b) {
    var A = new Date(a.getFullYear(), a.getMonth(), a.getDate());
    var B = new Date(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.round((B - A) / DAY_MS);
  }
  function formatHuman(d) {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
  }

  /* ---------- input parsing ---------- */

  function parseDeadline(text, now) {
    now = startOfDay(now || new Date());
    var s = String(text == null ? '' : text).trim().toLowerCase();
    if (!s) return { date: null, source: 'none' };

    var iso = parseISODate(s);
    if (iso) return { date: iso, source: 'iso' };

    if (s === 'today') return { date: now, source: 'relative' };
    if (s === 'tomorrow') return { date: addDays(now, 1), source: 'relative' };
    if (s === 'next week') return { date: addDays(now, 7), source: 'relative' };
    if (s === 'next month') return { date: addDays(now, 30), source: 'relative' };

    var rel = /^in\s+(\d{1,3})\s*(day|days|week|weeks|month|months)\b/.exec(s);
    if (rel) {
      var n = +rel[1], unit = rel[2];
      var mult = unit.indexOf('week') === 0 ? 7 : (unit.indexOf('month') === 0 ? 30 : 1);
      return { date: addDays(now, n * mult), source: 'relative' };
    }

    var days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    var wd = /\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/.exec(s);
    if (wd) {
      var target = days.indexOf(wd[1]);
      var diff = (target - now.getDay() + 7) % 7;
      if (diff === 0) diff = 7; // "by Friday" on a Friday means the next one
      return { date: addDays(now, diff), source: 'weekday' };
    }

    return { date: null, source: 'unparsed' };
  }

  function parseDailyMinutes(text) {
    var s = String(text || '').toLowerCase();
    var m = /(\d{1,3})\s*(minutes?|mins?|hours?|hrs?)\s*(?:a|per|each|\/)\s*day/.exec(s);
    if (!m) return null;
    var n = +m[1];
    if (/^h/.test(m[2])) n = Math.round(n * 60);
    if (n < 15 || n > 480) return null;
    return n;
  }

  function detectDomain(goal) {
    var text = ' ' + String(goal).toLowerCase() + ' ';
    var best = 'generic', bestScore = 0;
    Object.keys(DOMAINS).forEach(function (key) {
      if (key === 'generic') return;
      var score = 0;
      DOMAINS[key].keywords.forEach(function (kw) {
        var re = new RegExp('(^|[^a-z])' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z]|$)');
        if (re.test(text)) score += kw.indexOf(' ') >= 0 ? 2 : 1;
      });
      if (score > bestScore) { bestScore = score; best = key; }
    });
    return { key: best, score: bestScore };
  }

  function titleFromGoal(goal) {
    var g = String(goal).trim().replace(/\s+/g, ' ').replace(/[.!?]+$/, '');
    if (g.length > 64) {
      var cut = g.slice(0, 64);
      var space = cut.lastIndexOf(' ');
      g = (space > 40 ? cut.slice(0, space) : cut) + '…';
    }
    return g.charAt(0).toUpperCase() + g.slice(1);
  }

  function hashId(str) {
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  /* ---------- plan generation ---------- */

  function createPlan(input) {
    input = input || {};
    var now = startOfDay(input.now || new Date());
    var rawGoal = String(input.goal == null ? '' : input.goal).trim().replace(/\s+/g, ' ');

    if (!rawGoal) return { ok: false, code: 'EMPTY_GOAL', error: 'Describe your goal first — one sentence is enough.' };
    if (rawGoal.length < MIN_GOAL) return { ok: false, code: 'GOAL_TOO_SHORT', error: 'Add a little detail (' + MIN_GOAL + '+ characters): what do you want to finish, and by when?' };
    if (rawGoal.length > MAX_GOAL) return { ok: false, code: 'GOAL_TOO_LONG', error: 'That is ' + rawGoal.length + ' characters. Keep the goal under ' + MAX_GOAL + ' and put details in the tasks.' };

    var domainInfo = detectDomain(rawGoal);
    var domain = DOMAINS[domainInfo.key] || DOMAINS.generic;

    var deadlineInfo = parseDeadline(input.deadline, now);
    if (input.deadline && String(input.deadline).trim() && !deadlineInfo.date && deadlineInfo.source === 'unparsed') {
      return { ok: false, code: 'BAD_DEADLINE', error: 'Could not read that deadline. Use a date like 2026-11-15, or "in 3 weeks".' };
    }
    if (deadlineInfo.date && daysBetween(now, deadlineInfo.date) < 0) {
      return { ok: false, code: 'DEADLINE_PAST', error: 'That deadline is in the past. Pick a date from today onward.' };
    }

    var horizonDays;
    if (deadlineInfo.date) horizonDays = Math.max(2, daysBetween(now, deadlineInfo.date));
    else horizonDays = domain.horizon;

    var minutes = Number(input.minutesPerDay);
    if (!minutes || isNaN(minutes)) minutes = parseDailyMinutes(rawGoal) || 60;
    minutes = Math.max(15, Math.min(480, Math.round(minutes)));

    var tasks = [];
    var idx = 0;
    var phaseCount = domain.phases.length;
    domain.phases.forEach(function (phase, pi) {
      phase.tasks.forEach(function (t) {
        idx++;
        var explicit = t[3];
        var priority = explicit || (pi === 0 || pi === phaseCount - 1 ? 'P1' : 'P2');
        tasks.push({
          id: 't' + idx,
          title: t[0],
          detail: t[1],
          minutes: t[2],
          phase: phase.name,
          phaseIndex: pi,
          priority: priority
        });
      });
    });
    if (!tasks.some(function (t) { return t.priority === 'P1'; })) tasks[0].priority = 'P1';

    var total = tasks.reduce(function (s, t) { return s + t.minutes; }, 0);
    var cum = 0;
    var lastOffset = 0;
    tasks.forEach(function (t, i) {
      cum += t.minutes;
      var offset = total ? Math.round((cum / total) * (horizonDays - 1)) : 0;
      if (i === tasks.length - 1) offset = horizonDays - 1;
      if (offset < lastOffset) offset = lastOffset;
      lastOffset = offset;
      t.dayOffset = offset;
      t.dueDate = isoDate(addDays(now, offset));
    });

    var deadlineLabel = deadlineInfo.date ? formatHuman(deadlineInfo.date) : formatHuman(addDays(now, horizonDays - 1));
    var ctx = { goal: rawGoal, deadlineLabel: deadlineLabel, horizonDays: horizonDays, minutesPerDay: minutes, title: titleFromGoal(rawGoal) };

    var assumptions = [
      'Template: ' + domain.label + ' — deterministic rules, not AI-generated text.',
      deadlineInfo.date
        ? 'Deadline read as ' + deadlineLabel + ' (' + horizonDays + ' days from today).'
        : 'No deadline given, so a ' + horizonDays + '-day horizon is assumed.',
      'Time budget: about ' + minutes + ' minutes per day; task dates are spread across the horizon.',
      'Due dates are suggestions — move them to fit your real week.'
    ];
    if (horizonDays < tasks.length * 0.6) {
      assumptions.push('The horizon is tight for ' + tasks.length + ' tasks: expect to combine short tasks or extend the deadline.');
    }
    if (deadlineInfo.source === 'weekday' && input.deadline) {
      assumptions.push('Weekday deadline resolved to the next ' + input.deadline + '.');
    }

    var drafts = (domain.drafts || []).map(function (fn) { return fn(ctx); });

    return {
      ok: true,
      plan: {
        id: hashId(rawGoal + '|' + isoDate(now) + '|' + horizonDays + '|' + minutes),
        version: VERSION,
        createdAt: isoDate(now),
        goal: rawGoal,
        title: ctx.title,
        domain: domainInfo.key,
        domainLabel: domain.label,
        domainConfidence: domainInfo.score > 0 ? 'matched' : 'generic fallback',
        summary: domain.summary,
        deadline: deadlineInfo.date ? isoDate(deadlineInfo.date) : null,
        deadlineLabel: deadlineLabel,
        horizonDays: horizonDays,
        minutesPerDay: minutes,
        startDate: isoDate(now),
        tasks: tasks,
        drafts: drafts,
        assumptions: assumptions,
        stats: {
          taskCount: tasks.length,
          totalMinutes: total,
          totalHours: Math.round((total / 60) * 10) / 10,
          p1Count: tasks.filter(function (t) { return t.priority === 'P1'; }).length,
          phaseCount: phaseCount
        }
      }
    };
  }

  /* ---------- exports ---------- */

  function toMarkdown(plan, doneIds) {
    if (!plan || !plan.tasks) throw new Error('toMarkdown: plan required');
    var done = doneIds && typeof doneIds === 'object' ? doneIds : {};
    var lines = [];
    lines.push('# ' + plan.title);
    lines.push('');
    lines.push('**Goal:** ' + plan.goal);
    lines.push('');
    lines.push('**Plan:** ' + plan.domainLabel + ' · ' + plan.stats.taskCount + ' tasks · ' +
      plan.stats.totalHours + 'h estimated · due ' + plan.deadlineLabel);
    lines.push('');
    lines.push('**Generated:** ' + plan.createdAt + ' by TaskPilot AI (deterministic planner, no AI model).');
    lines.push('');
    var completed = plan.tasks.filter(function (t) { return done[t.id]; }).length;
    lines.push('**Progress at export:** ' + completed + '/' + plan.tasks.length + ' tasks done.');
    lines.push('');
    lines.push('> ' + plan.summary);
    lines.push('');

    var phases = [];
    plan.tasks.forEach(function (t) {
      var group = phases[phases.length - 1];
      if (!group || group.name !== t.phase) { phases.push({ name: t.phase, tasks: [t] }); }
      else group.tasks.push(t);
    });

    phases.forEach(function (group) {
      lines.push('## ' + group.name);
      lines.push('');
      group.tasks.forEach(function (t) {
        var box = done[t.id] ? '[x]' : '[ ]';
        lines.push('- ' + box + ' **' + t.priority + '** — ' + t.title);
        lines.push('  - ' + t.detail);
        lines.push('  - ' + t.minutes + ' min · due ' + t.dueDate);
      });
      lines.push('');
    });

    if (plan.drafts && plan.drafts.length) {
      lines.push('## Draft outputs');
      lines.push('');
      plan.drafts.forEach(function (d) {
        lines.push('### ' + d.title);
        lines.push('');
        lines.push('```text');
        lines.push(d.body);
        lines.push('```');
        lines.push('');
      });
    }

    lines.push('## Assumptions');
    lines.push('');
    plan.assumptions.forEach(function (a) { lines.push('- ' + a); });
    lines.push('');
    lines.push('---');
    lines.push('Generated offline by TaskPilot AI. Edit freely — the plan is a starting point, not a contract.');
    return lines.join('\n');
  }

  function icsEscape(s) {
    return String(s == null ? '' : s)
      .replace(/\\/g, '\\\\')
      .replace(/;/g, '\\;')
      .replace(/,/g, '\\,')
      .replace(/\r?\n/g, '\\n');
  }

  function foldLine(line) {
    // RFC 5545: fold at 75 octets, continuation starts with a single space.
    var encoder = new TextEncoder();
    var out = '';
    var bytes = 0;
    for (var i = 0; i < line.length; i++) {
      var ch = line.charAt(i);
      var size = encoder.encode(ch).length;
      if (bytes + size > 75) {
        out += '\r\n ';
        bytes = 1;
      }
      out += ch;
      bytes += size;
    }
    return out;
  }

  function icsDate(d) {
    var m = d.getMonth() + 1, day = d.getDate();
    return '' + d.getFullYear() + (m < 10 ? '0' + m : m) + (day < 10 ? '0' + day : day);
  }

  function toICS(plan, now) {
    if (!plan || !plan.tasks) throw new Error('toICS: plan required');
    now = now || new Date();
    var stamp = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate(),
      now.getHours(), now.getMinutes(), now.getSeconds()));
    var dtstamp = stamp.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    var priorityMap = { P1: 1, P2: 5, P3: 9 };
    var lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//TaskPilot AI//TaskPilot ' + VERSION + '//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      'X-WR-CALNAME:' + icsEscape('TaskPilot — ' + plan.title),
      'X-WR-TIMEZONE:UTC'
    ];
    plan.tasks.forEach(function (t) {
      var start = parseISODate(t.dueDate);
      if (!start) return;
      var end = addDays(start, 1);
      lines.push('BEGIN:VEVENT');
      lines.push('UID:' + plan.id + '-' + t.id + '@taskpilot.local');
      lines.push('DTSTAMP:' + dtstamp);
      lines.push('DTSTART;VALUE=DATE:' + icsDate(start));
      lines.push('DTEND;VALUE=DATE:' + icsDate(end));
      lines.push('SUMMARY:' + icsEscape('[' + t.priority + '] ' + t.title));
      lines.push('DESCRIPTION:' + icsEscape(t.detail + '\n\nGoal: ' + plan.goal + '\nEstimated: ' + t.minutes + ' min'));
      lines.push('CATEGORIES:TaskPilot,' + icsEscape(plan.domainLabel));
      lines.push('PRIORITY:' + (priorityMap[t.priority] || 5));
      lines.push('TRANSP:TRANSPARENT');
      lines.push('END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    return lines.map(foldLine).join('\r\n') + '\r\n';
  }

  return {
    VERSION: VERSION,
    MIN_GOAL: MIN_GOAL,
    MAX_GOAL: MAX_GOAL,
    createPlan: createPlan,
    parseDeadline: parseDeadline,
    parseDailyMinutes: parseDailyMinutes,
    detectDomain: detectDomain,
    toMarkdown: toMarkdown,
    toICS: toICS,
    isoDate: isoDate,
    formatHuman: formatHuman,
    addDays: addDays
  };
});
